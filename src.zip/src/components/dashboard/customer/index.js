export { default as CustomerContactDetails } from './CustomerContactDetails';
export { default as CustomerDataManagement } from './CustomerDataManagement';
export { default as CustomerEditForm } from './CustomerEditForm';
export { default as CustomerEmailsSummary } from './CustomerEmailsSummary';
export { default as CustomerInvoices } from './CustomerInvoices';
export { default as CustomerInvoicesSummary } from './CustomerInvoicesSummary';
export { default as CustomerListTable } from './CustomerListTable';
export { default as CustomerLogs } from './CustomerLogs';
