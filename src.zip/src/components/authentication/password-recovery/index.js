export { default as PasswordRecoveryAmplify } from './PasswordRecoveryAmplify';
